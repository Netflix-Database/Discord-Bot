# Netdb

Discord Bot for various Netflix series and movies.

Yannick retired from tha HTL

F r e c h

nemma des ois chat

sicha
